package com.lti.Hibernate.Book_db;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


//One to One Unidirectional Example

@Entity
@Table(name = "bookss1")
public class Book {

	private long id;
	private String title;
	private String description;
	private Date publisheDate;
	private Author author;

	public Book() {
		super();
	}

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator= "book_sequence")
	@SequenceGenerator(name="book_sequence" , sequenceName= "book_seq1")
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	@Temporal(TemporalType.DATE)
	@Column(name = "publisheDate")
	public Date getPublisheDate() {
		return publisheDate;
	}


	public void setPublisheDate(Date publisheDate) {
		this.publisheDate = publisheDate;
	}

	@OneToOne( cascade = CascadeType.ALL)
	@JoinColumn( name = "id" )
	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}
	
	
	
	

	
}
