package com.lti.project.Model;

public class Marks {
	
	protected int student_id;
	protected int course_id;
	protected int instructor_id;
	protected int ia_marks;
	
	public Marks() {

	}
	
	public Marks(int student_id, int course_id, int instructor_id, int ia_marks) {
		super();
		this.student_id = student_id;
		this.course_id = course_id;
		this.instructor_id = instructor_id;
		this.ia_marks = ia_marks;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public int getInstructor_id() {
		return instructor_id;
	}

	public void setInstructor_id(int instructor_id) {
		this.instructor_id = instructor_id;
	}

	public int getIa_marks() {
		return ia_marks;
	}

	public void setIa_marks(int ia_marks) {
		this.ia_marks = ia_marks;
	}

	@Override
	public String toString() {
		return "Marks [student_id=" + student_id + ", course_id=" + course_id + ", instructor_id=" + instructor_id
				+ ", ia_marks=" + ia_marks + "]";
	}
	 
}
