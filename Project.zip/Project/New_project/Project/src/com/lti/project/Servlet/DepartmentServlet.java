package com.lti.project.Servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.project.DAO.DepartmentDAO;
import com.lti.project.Model.Department;


@WebServlet("/bbbb")
public class DepartmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

private DepartmentDAO deptDAO;
	
	public void init() {
		deptDAO = new DepartmentDAO();
	}
	
    public DepartmentServlet() {
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewFormDept(request, response);
				break;
			case "/insert":
				insertDept(request, response);
				break;
			case "/delete":
				deleteDept(request, response);
				break;
			case "/edit":
				showEditFormDept(request, response);
				break;
			case "/update":
				updateDept(request, response);
				break;
			default:
				listDept(request, response);
				break;
			}
		} catch (Exception ex) {
			throw new ServletException(ex);
		}
	}

	private void listDept(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Department> listUser = deptDAO.selectAllDept();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Department-list.jsp");
		dispatcher.forward(request, response);
		
	}

	private void updateDept(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
	
		int department_id = Integer.parseInt(request.getParameter("department_id"));
		String department_name = request.getParameter("department_name");
		String department_location = request.getParameter("department_location");
		Department st = new Department(department_id,department_name,department_location);
		deptDAO.updateDept(st);
		response.sendRedirect("list");
		
	}

	private void showEditFormDept(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int department_id = Integer.parseInt(request.getParameter("department_id"));
		Department existingUser = deptDAO.selectDept(department_id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Department-form.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);
		
	}

	private void deleteDept(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
	
		int department_id = Integer.parseInt(request.getParameter("department_id"));
		deptDAO.deleteDept(department_id);
		response.sendRedirect("list");
		
	}

	private void insertDept(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
	
		String department_name = request.getParameter("department_name");
		String department_location= request.getParameter("department_location");

		Department newUser = new Department(department_name, department_location);
		deptDAO.insertDept(newUser);
		response.sendRedirect("list");
	}

	private void showNewFormDept(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		RequestDispatcher dispatcher = request.getRequestDispatcher("Department-form.jsp");
		dispatcher.forward(request, response);
	
	}



}
