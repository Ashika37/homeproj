package com.lti.project.Servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.project.DAO.CourseDAO;
import com.lti.project.DAO.StudentDAO;
import com.lti.project.Model.Course;
import com.lti.project.Model.Student;

@WebServlet("/")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

private StudentDAO studentDAO;
	
	public void init() {
		studentDAO = new StudentDAO();
	}
	
    public StudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewFormStudent(request, response);
				break;
			case "/insert":
				insertStudent(request, response);
				break;
			case "/delete":
				deleteStudent(request, response);
				break;
			case "/edit":
				showEditFormStudent(request, response);
				break;
			case "/update":
				updateStudent(request, response);
				break;
			default:
				listStudent(request, response);
				break;
			}
		} catch (Exception ex) {
			throw new ServletException(ex);
		}
	}

	private void listStudent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		List<Student> listUser = studentDAO.selectAllStudent();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Student-list.jsp");
		dispatcher.forward(request, response);
		
	}

	private void updateStudent(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		int student_id = Integer.parseInt(request.getParameter("student_id"));
		String student_name = request.getParameter("student_name");
		String dob = request.getParameter("dob");
		int course_id = Integer.parseInt(request.getParameter("course_id"));
		int instructor_id = Integer.parseInt(request.getParameter("instructor_id"));
		Student st = new Student(student_id,student_name,dob,course_id,instructor_id);
		studentDAO.updateStudent(st);
		response.sendRedirect("list");
	}

	private void showEditFormStudent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int student_id = Integer.parseInt(request.getParameter("student_id"));
		Student existingUser = studentDAO.selectStudent(student_id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Student-form.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);
	}

	private void deleteStudent(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		int student_id = Integer.parseInt(request.getParameter("student_id"));
		studentDAO.deleteStudent(student_id);
		response.sendRedirect("list");
		
	}

	private void insertStudent(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		String student_name = request.getParameter("student_name");
		String dob= request.getParameter("dob");
		int course_id =Integer.parseInt( request.getParameter("course_id"));
		int instructor_id =Integer.parseInt( request.getParameter("instructor_id"));
		Student newUser = new Student(student_name, dob,course_id,instructor_id);
		studentDAO.insertStudent(newUser);
		response.sendRedirect("list");
	}

	private void showNewFormStudent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		RequestDispatcher dispatcher = request.getRequestDispatcher("Student-form.jsp");
		dispatcher.forward(request, response);
	}



}
