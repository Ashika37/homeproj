package com.lti.project.Servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.project.DAO.CourseDAO;
import com.lti.project.DAO.DepartmentDAO;
import com.lti.project.Model.Course;
import com.lti.project.Model.Department;

/**
 * Servlet implementation class CourseServlet
 */
@WebServlet("/SSSS")
public class CourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

private CourseDAO courseDAO;
	
	public void init() {
		courseDAO = new CourseDAO();
	}
	
    public CourseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewFormCourse(request, response);
				break;
			case "/insert":
				insertCourse(request, response);
				break;
			case "/delete":
				deleteCourse(request, response);
				break;
			case "/edit":
				showEditFormCourse(request, response);
				break;
			case "/update":
				updateCourse(request, response);
				break;
			default:
				listCourse(request, response);
				break;
			}
		} catch (Exception ex) {
			throw new ServletException(ex);
		}
	}

	private void listCourse(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		List<Course> listUser = courseDAO.selectAllCourse();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Course-list.jsp");
		dispatcher.forward(request, response);
		
	}

	private void updateCourse(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {

		int course_id = Integer.parseInt(request.getParameter("course_id"));
		String duration = request.getParameter("duration");
		String course_name = request.getParameter("course_name");
		int student_id = Integer.parseInt(request.getParameter("student_id"));
		Course st = new Course(course_id,duration,course_name,student_id);
		courseDAO.updateCourse(st);
		response.sendRedirect("list");
	}

	private void showEditFormCourse(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int course_id = Integer.parseInt(request.getParameter("course_id"));
		Course existingUser = courseDAO.selectCourse(course_id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Course-form.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);
		
	}

	private void deleteCourse(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
	
		int course_id = Integer.parseInt(request.getParameter("course_id"));
		courseDAO.deleteCourse(course_id);
		response.sendRedirect("list");
		
	}

	private void insertCourse(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {

		String duration = request.getParameter("duration");
		String course_name= request.getParameter("course_name");
		int student_id =Integer.parseInt( request.getParameter("student_id"));
		Course newUser = new Course(duration, course_name,student_id);
		courseDAO.insertCourse(newUser);
		response.sendRedirect("list");
	}

	private void showNewFormCourse(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		RequestDispatcher dispatcher = request.getRequestDispatcher("Course-form.jsp");
		dispatcher.forward(request, response);
	}




}
