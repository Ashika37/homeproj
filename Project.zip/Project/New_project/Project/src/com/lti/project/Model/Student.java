package com.lti.project.Model;

public class Student {

	protected int student_id;
	protected String student_name;
	protected String dob;
	protected int course_id;
	protected int instructor_id;
	
	public Student() {
	}

	public Student(int student_id, String student_name, String dob, int course_id, int instructor_id) {
		super();
		this.student_id = student_id;
		this.student_name = student_name;
		this.dob = dob;
		this.course_id = course_id;
		this.instructor_id = instructor_id;
	}
	
	public Student(String student_name, String dob, int course_id, int instructor_id) {
		super();
		this.student_name = student_name;
		this.dob = dob;
		this.course_id = course_id;
		this.instructor_id = instructor_id;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public int getInstructor_id() {
		return instructor_id;
	}

	public void setInstructor_id(int instructor_id) {
		this.instructor_id = instructor_id;
	}

	@Override
	public String toString() {
		return "Student [student_id=" + student_id + ", student_name=" + student_name + ", dob=" + dob + ", course_id="
				+ course_id + ", instructor_id=" + instructor_id + "]";
	}
	
	
	
	
}
