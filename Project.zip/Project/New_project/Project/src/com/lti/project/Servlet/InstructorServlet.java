package com.lti.project.Servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.project.DAO.InstructorDAO;
import com.lti.project.Model.Instructor;

@WebServlet("/InstructorServlet")
public class InstructorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private InstructorDAO instructorDAO;
	
	public void init() {
		instructorDAO = new InstructorDAO();
	}
	
    public InstructorServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewFormInstructor(request, response);
				break;
			case "/insert":
				insertInstructor(request, response);
				break;
			case "/delete":
				deleteInstructor(request, response);
				break;
			case "/edit":
				showEditFormInstructor(request, response);
				break;
			case "/update":
				updateInstructor(request, response);
				break;
			default:
				listInstructor(request, response);
				break;
			}
		} catch (Exception ex) {
			throw new ServletException(ex);
		}
	}
	
	private void listInstructor(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Instructor> listUser = instructorDAO.selectAllInstructor();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("instructor-list.jsp");
		dispatcher.forward(request, response);
		
	}

	private void updateInstructor(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		int instructor_id = Integer.parseInt(request.getParameter("instructor_id"));
		String instructor_name = request.getParameter("instructor_name");
		int telephone_no = Integer.parseInt(request.getParameter("telephone_no"));
		int room_no = Integer.parseInt(request.getParameter("room_no"));
		int department_id = Integer.parseInt(request.getParameter("department_id"));

		Instructor book = new Instructor(instructor_id, instructor_name, telephone_no, room_no,department_id);
		instructorDAO.updateUser(book);
		response.sendRedirect("list");
	}

	private void showEditFormInstructor(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int instructor_id = Integer.parseInt(request.getParameter("instructor_id"));
		Instructor existingUser = instructorDAO.selectInstructor(instructor_id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("inst-form.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);
	}

	private void deleteInstructor(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		int instructor_id = Integer.parseInt(request.getParameter("instructor_id"));
		instructorDAO.deleteInstructor(instructor_id);
		response.sendRedirect("list");
		
	}

	private void insertInstructor(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		String instructor_name = request.getParameter("instructor_name");
		int telephone_no = Integer.parseInt(request.getParameter("telephone_no"));
		int room_no = Integer.parseInt(request.getParameter("room_no"));
		int department_id = Integer.parseInt(request.getParameter("department_id"));

		Instructor newUser = new Instructor(instructor_name,telephone_no,room_no,department_id);
		instructorDAO.insertInstructor(newUser);
		response.sendRedirect("list");
		
	}

	private void showNewFormInstructor(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("instructor-form.jsp");
		dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
