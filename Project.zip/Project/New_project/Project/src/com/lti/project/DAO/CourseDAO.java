package com.lti.project.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.project.Model.Course;
import com.lti.project.Model.Department;

public class CourseDAO {

	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "tiger";

	private static final String INSERT_COURSE_SQL = "INSERT INTO Course10 VALUES "
			+ " (course_seq.NEXTVAL,?,?,?)";

	private static final String SELECT_COURSE_BY_ID = "select  course_id,duration,course_name,"
			+ "student_id from Course10 where course_id =?";
	private static final String SELECT_ALL_COURSE = "select * from Course10";
	private static final String DELETE_COURSE_SQL = "delete from Course10 where course_id = ?";
	private static final String UPDATE_COURSE_SQL = "update Course10 set duration = ?,"
			+ "course_name= ?,student_id=? where course_id = ?";

	public CourseDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertCourse(Course user) throws SQLException {
		System.out.println(INSERT_COURSE_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_COURSE_SQL);
			preparedStatement.setString(1, user.getDuration());
			preparedStatement.setString(2, user.getCourse_name());
			preparedStatement.setInt(3, user.getStudent_id());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Course selectCourse(int course_id) {
		Course user = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_COURSE_BY_ID);
			preparedStatement.setInt(1, course_id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String duration = rs.getString("duration");
				String course_name = rs.getString("course_name");
				int student_id = rs.getInt("student_id");
				user = new Course(course_id,duration,course_name,student_id);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<Course> selectAllCourse() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Course> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_COURSE);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int course_id = rs.getInt("course_id");
				String duration = rs.getString("duration");
				String course_name = rs.getString("course_name");
				int student_id = rs.getInt("student_id");
				users.add(new Course(course_id,duration, course_name,student_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteCourse(int course_id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_COURSE_SQL);) {
			statement.setInt(1, course_id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateCourse(Course user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_COURSE_SQL);) {
			
			statement.setString(1, user.getDuration());
			statement.setString(2, user.getCourse_name());
			statement.setInt(3, user.getStudent_id());
			statement.setInt(4, user.getCourse_id());
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}
	
}
