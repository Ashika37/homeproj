package com.lti.project.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.project.Model.Course;
import com.lti.project.Model.Student;

public class StudentDAO {
	
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "tiger";

	private static final String INSERT_STUDENT_SQL = "INSERT INTO Student10 VALUES "
			+ " (student_seq.NEXTVAL,?,?,?,?)";

	private static final String SELECT_STUDENT_BY_ID = "select  student_id,student_name,dob,"
			+ "course_id,instructor_id from Student10 where student_id =?";
	private static final String SELECT_ALL_STUDENT = "select * from Student10";
	private static final String DELETE_STUDENT_SQL = "delete from Student10 where student_id = ?";
	private static final String UPDATE_STUDENT_SQL = "update Student10 set student_name = ?,"
			+ "dob= ?,course_id=?,instructor_id=? where student_id = ?";

	public StudentDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertStudent(Student user) throws SQLException {
		System.out.println(INSERT_STUDENT_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_STUDENT_SQL);
			preparedStatement.setString(1, user.getStudent_name());
			preparedStatement.setString(2, user.getDob());
			preparedStatement.setInt(3, user.getCourse_id());
			preparedStatement.setInt(4, user.getInstructor_id());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Student selectStudent(int student_id) {
		Student user = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_STUDENT_BY_ID);
			preparedStatement.setInt(1, student_id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String student_name = rs.getString("student_name");
				String dob = rs.getString("dob");
				int course_id = rs.getInt("course_id");
				int instructor_id = rs.getInt("instructor_id");
				user = new Student(course_id,student_name,dob, course_id,instructor_id);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<Student> selectAllStudent() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Student> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_STUDENT);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int student_id = rs.getInt("student_id");
				String student_name = rs.getString("student_name");
				String dob = rs.getString("dob");
				int course_id = rs.getInt("course_id");
				int instructor_id = rs.getInt("instructor_id");
				users.add(new Student(student_id,student_name, dob,course_id,instructor_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteStudent(int student_id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_STUDENT_SQL);) {
			statement.setInt(1, student_id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateStudent(Student user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_STUDENT_SQL);) {
			
			statement.setString(1, user.getStudent_name());
			statement.setString(2, user.getDob());
			statement.setInt(3, user.getCourse_id());
			statement.setInt(4, user.getInstructor_id());
			statement.setInt(4, user.getStudent_id());
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}

}
