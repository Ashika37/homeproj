package com.lti.project.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.project.Model.Instructor;

public class InstructorDAO {

	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "tiger";

	private static final String INSERT_INSTRUCTOR_SQL = "INSERT INTO Instructor VALUES "
			+ " (instructor_seq.NEXTVAL,?, ?, ?, ?)";

	private static final String SELECT_INSTRUCTOR_BY_ID = "select  instructor_id,instructor_name,telephone_no,"
			+ "room_no,department_id from Instructor where instructor_id =?";
	private static final String SELECT_ALL_INSTRUCTOR = "select * from Instructor";
	private static final String DELETE_INSTRUCTOR_SQL = "delete from Instructor where instructor_id = ?";
	private static final String UPDATE_INSTRUCTOR_SQL = "update Instructor set instructor_name = ?,"
			+ "telephone_no= ?, room_no =?, department_id =? where instructor_id = ?";

	public InstructorDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertInstructor(Instructor user) throws SQLException {
		System.out.println(INSERT_INSTRUCTOR_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_INSTRUCTOR_SQL);
			preparedStatement.setString(1, user.getInstructor_name());
			preparedStatement.setInt(2, user.getTelephone_no());
			preparedStatement.setInt(3, user.getRoom_no());
			preparedStatement.setInt(4, user.getDepartment_id());

			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Instructor selectInstructor(int instructor_id) {
		Instructor user = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_INSTRUCTOR_BY_ID);
			preparedStatement.setInt(1, instructor_id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String instructor_name = rs.getString("instructor_name");
				int telephone_no = rs.getInt("telephone_no");
				int room_no = rs.getInt("room_no");
				int department_id = rs.getInt("department_id");
				user = new Instructor(instructor_id,instructor_name,telephone_no,room_no,department_id);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<Instructor> selectAllInstructor() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Instructor> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_INSTRUCTOR);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int instructor_id = rs.getInt("instructor_id");
				String instructor_name = rs.getString("instructor_name");
				int telephone_no = rs.getInt("telephone_no");
				int room_no = rs.getInt("room_no");
				int department_id = rs.getInt("department_id");
				users.add(new Instructor(instructor_id,instructor_name,telephone_no,room_no,department_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteInstructor(int instructor_id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
												(DELETE_INSTRUCTOR_SQL);) {
			statement.setInt(1, instructor_id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(Instructor user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement
						(UPDATE_INSTRUCTOR_SQL);) {
			
			statement.setString(1, user.getInstructor_name());
			statement.setInt(2, user.getTelephone_no());
			statement.setInt(3, user.getRoom_no());
			statement.setInt(4, user.getDepartment_id());
			statement.setInt(5, user.getInstructor_id());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}
	
}
