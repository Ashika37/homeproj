package com.lti.project.DAO;

public class MarksDAO {

}
