package com.lti.project.Model;

public class Instructor {
	
	protected int  instructor_id;
	protected String instructor_name;
	protected int telephone_no;
	protected int  room_no;
	protected int department_id;
	
	public Instructor() {
	}
	
	public Instructor(int instructor_id, String instructor_name, int telephone_no, int room_no, int department_id) {
		super();
		this.instructor_id = instructor_id;
		this.instructor_name = instructor_name;
		this.telephone_no = telephone_no;
		this.room_no = room_no;
		this.department_id = department_id;
	}
	
	public Instructor(String instructor_name, int telephone_no, int room_no, int department_id) {
		super();
		this.instructor_name = instructor_name;
		this.telephone_no = telephone_no;
		this.room_no = room_no;
		this.department_id = department_id;
	}

	public int getInstructor_id() {
		return instructor_id;
	}

	public void setInstructor_id(int instructor_id) {
		this.instructor_id = instructor_id;
	}

	public String getInstructor_name() {
		return instructor_name;
	}

	public void setInstructor_name(String instructor_name) {
		this.instructor_name = instructor_name;
	}

	public int getTelephone_no() {
		return telephone_no;
	}

	public void setTelephone_no(int telephone_no) {
		this.telephone_no = telephone_no;
	}

	public int getRoom_no() {
		return room_no;
	}

	public void setRoom_no(int room_no) {
		this.room_no = room_no;
	}

	public int getDepartment_id() {
		return department_id;
	}

	public void setDepartment_id(int department_id) {
		this.department_id = department_id;
	}

	@Override
	public String toString() {
		return "Instructor [instructor_id=" + instructor_id + ", instructor_name=" + instructor_name + ", telephone_no="
				+ telephone_no + ", room_no=" + room_no + ", department_id=" + department_id + "]";
	}
	
}
